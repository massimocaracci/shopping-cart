package com.lendable.model

data class Item(val id: String, val name: String, val price: Double)